"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { CafeEvent } from "../components/events-page/types";
import EventCard from "../components/events-page/EventCard";
import CalendarFilter from "../components/events-page/CalendarFilter";
import RsvpModal from "../components/events-page/RsvpModal";

const EVENTS_DATA: CafeEvent[] = [
  {
    id: 1,
    title: "Chamber Music & Merlot",
    subtitle: "A Candlelight Classical Evening",
    date: "June 20, 2026",
    time: "20:00 - 23:00",
    location: "Potsdamer Straße Parlor",
    description:
      "Immerse yourself in a warm, candlelit atmosphere as our local string quartet performs select movements from Bach, Mozart, and Beethoven. Ticket includes a curated tasting flight of premium Italian Merlot and artisan cheese pairings.",
    image: "/assets/clint-images/event 1.png",
    category: "music",
    price: "€45 / person",
    frameType: "walnut",
  },
  {
    id: 2,
    title: "Jazz Quintet & Cold Brews",
    subtitle: "Syncopated Rhythms & Velvet Notes",
    date: "July 03, 2026",
    time: "21:00 - 00:00",
    location: "Schiffbauerdamm Seating",
    description:
      "Experience the vibrant pulse of local late-night jazz. Our featured quintet brings smooth tenor sax solos and vintage swing beats. Enjoy specialty cold-brew-infused coffee cocktails, roasted espresso appetizers, and chocolate flights.",
    image: "/assets/clint-images/evening-image.jpeg",
    category: "music",
    price: "€25 / entry",
    frameType: "gold",
  },
  {
    id: 3,
    title: "Poetry Slam & Artisan Lattes",
    subtitle: "Spoken Word in the Secret Garden",
    date: "July 18, 2026",
    time: "19:00 - 22:00",
    location: "Potsdamer Straße Parlor",
    description:
      "Berlin's underground wordsmiths convene under our cozy garden lights. Engage in raw, heartfelt poetry, competitive slams, and ambient soundscapes. Ticket includes custom barista-poured latte art and freshly baked organic pastries.",
    image: "/assets/clint-images/event 2.png",
    category: "literary",
    price: "€15 / person",
    frameType: "black",
  },
  {
    id: 4,
    title: "Coffee Cupping & Roastery Masterclass",
    subtitle: "Sensory Journey of Single Origins",
    date: "August 01, 2026",
    time: "10:00 - 13:00",
    location: "Cafe Beatz Main Roastery",
    description:
      "Join our head roaster for a professional cupping session. Learn to identify taste notes, roast profiles, and bean origins from Ethiopia, Colombia, and Yemen. Roast your own small batch of beans to take home in a vintage tin.",
    image: "/assets/clint-images/Page 2 ....2.png",
    category: "coffee",
    price: "€60 / person",
    frameType: "canvas",
  },
  {
    id: 5,
    title: "Sunday Vinyl & Vintage Brunch",
    subtitle: "Classic Mid-Century Soul & Fresh Sourdough",
    date: "August 16, 2026",
    time: "11:00 - 15:00",
    location: "Potsdamer Straße Parlor",
    description:
      "Unwind your Sunday to the warm crackle of soul, jazz, and folk records selected live. Indulge in an endless artisanal brunch board containing local honey, organic eggs, sourdough, and unlimited prosecco-mimosas.",
    image: "/assets/clint-images/ChatGPT Image May 20, 2026, 05_44_08 PM.png",
    category: "music",
    price: "€35 / person",
    frameType: "gold",
  },
  {
    id: 6,
    title: "The Art of Espresso & Pour Over",
    subtitle: "Unlock Professional Barista Skills",
    date: "August 29, 2026",
    time: "14:00 - 17:00",
    location: "Schiffbauerdamm Seating",
    description:
      "Master the variables of the perfect extraction. Learn milk texture dynamics, temperature profiling, and pour-over geometry (V60 & Chemex). Ideal for home coffee enthusiasts aiming to raise their daily brewing craft.",
    image: "/assets/clint-images/event 3.png",
    category: "coffee",
    price: "€50 / person",
    frameType: "walnut",
  },
];

const ITEMS_PER_PAGE = 3;

export default function EventsPage() {
  const [filter, setFilter] = useState<"all" | "music" | "coffee" | "literary">(
    "all",
  );
  const [currentPage, setCurrentPage] = useState(1);
  const [activeEvent, setActiveEvent] = useState<CafeEvent | null>(null);
  const [isRsvpOpen, setIsRsvpOpen] = useState(false);

  // Parallax Hero state
  const [offsetY, setOffsetY] = useState(0);

  // Date Filter state
  const [selectedDateFilter, setSelectedDateFilter] = useState<string | null>(
    null,
  );

  // Handle parallax scroll for hero
  useEffect(() => {
    const handleScroll = () => {
      setOffsetY(window.scrollY);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Filter events by both Category and specific Date
  const filteredEvents = EVENTS_DATA.filter((ev) => {
    const matchesCategory = filter === "all" || ev.category === filter;
    const matchesDate = !selectedDateFilter || ev.date === selectedDateFilter;
    return matchesCategory && matchesDate;
  });

  // Reset page when filter/date changes
  useEffect(() => {
    setCurrentPage(1);
  }, [filter, selectedDateFilter]);

  // Calculate pagination
  const totalPages = Math.ceil(filteredEvents.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const paginatedEvents = filteredEvents.slice(
    startIndex,
    startIndex + ITEMS_PER_PAGE,
  );

  const openRsvp = (ev: CafeEvent) => {
    setActiveEvent(ev);
    setIsRsvpOpen(true);
  };

  return (
    <div className="relative min-h-screen w-full bg-[#F4F1EA] text-[#3E2723] flex flex-col justify-between overflow-x-hidden">
      {/* 1. Hero Banner: Reused from Home Page layout */}
      <section className="relative w-full h-[350px] md:h-[60vh] flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-x-0 -top-[15%] h-[130%] z-0 will-change-transform"
          style={{ transform: `translateY(${offsetY * 0.4}px)` }}
        >
          <Image
            src="/assets/clint-images/Cover photo.png"
            alt="Antique 1920s Cafe Interior"
            fill
            priority
            className="object-cover object-center !w-full !h-full"
          />
          <div className="absolute inset-0 bg-black/65"></div>
        </div>

        <div className="relative z-10 flex flex-col items-center text-center px-4 mt-8">
          <h1 className="font-script text-[#F4F1EA] text-5xl md:text-7xl mb-4 drop-shadow-lg">
            Events & Catering
          </h1>
          <p className="text-[#D7CCC8] text-xs md:text-sm tracking-[0.3em] uppercase max-w-lg leading-relaxed">
            Where Timeless Vintage Charm Meets Modern Experiences
          </p>
        </div>
      </section>

      {/* Main Content Area */}
      <main className="max-w-6xl mx-auto w-full px-4 md:px-8 py-12 md:py-24 flex-grow">
        {/* Category Filter, Calendar Icon, and Meta info */}
        <div className="mb-16 flex flex-col sm:flex-row items-center justify-between gap-6 border-b border-[#3E2723]/10 pb-6">
          <div className="text-center sm:text-left flex flex-col sm:flex-row sm:items-end gap-3.5">
            <div>
              <span className="text-[10px] tracking-[0.3em] uppercase font-bold opacity-60">
                cultural salon
              </span>
              <h2 className="text-2xl md:text-3xl font-medium tracking-wide mt-1 font-sans">
                Upcoming Schedule
              </h2>
            </div>
            {/* Active Date Filter indicator */}
            {selectedDateFilter && (
              <motion.button
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                onClick={() => setSelectedDateFilter(null)}
                className="self-center sm:self-auto sm:mb-1.5 px-3 py-1 bg-[#C5A880]/15 border border-[#C5A880]/30 rounded-full text-[10px] md:text-xs font-bold text-[#3E2723] hover:bg-[#C5A880]/30 transition-colors flex items-center gap-1.5 cursor-pointer uppercase tracking-wider"
              >
                <span>Date: {selectedDateFilter.split(",")[0]}</span>
                <span className="opacity-60 text-xs">×</span>
              </motion.button>
            )}
          </div>

          <div className="flex flex-wrap gap-2 text-xs md:text-sm font-medium uppercase tracking-widest justify-center items-center">
            {/* Categories */}
            {(["all", "music", "coffee", "literary"] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  setFilter(cat);
                  setSelectedDateFilter(null); // Reset date filter to avoid empty sets
                }}
                className={`px-4 py-2 border rounded-full transition-all cursor-pointer ${
                  filter === cat && !selectedDateFilter
                    ? "bg-[#3E2723] text-[#F4F1EA] border-[#3E2723]"
                    : "border-[#3E2723]/20 hover:border-[#3E2723] opacity-70 hover:opacity-100"
                }`}
              >
                {cat}
              </button>
            ))}

            {/* Custom Interactive Calendar Filter Dropdown component */}
            <CalendarFilter
              selectedDateFilter={selectedDateFilter}
              onSelectDate={(dateStr) => {
                setSelectedDateFilter(dateStr);
                if (dateStr) {
                  setFilter("all"); // Reset category filter to prevent conflicts
                }
              }}
              eventsData={EVENTS_DATA}
            />
          </div>
        </div>

        {/* Listing layout */}
        {filteredEvents.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center bg-[#FAF8F5]/50 border border-dashed border-[#3E2723]/10 p-8">
            <p className="opacity-60 text-lg italic">
              No events currently scheduled on this selection.
            </p>
            <div className="mt-4 flex gap-4 justify-center">
              <button
                onClick={() => {
                  setFilter("all");
                  setSelectedDateFilter(null);
                }}
                className="text-xs font-bold uppercase tracking-wider underline cursor-pointer hover:text-[#5D4037]"
              >
                Reset All Filters
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-32 mb-16">
            {paginatedEvents.map((ev, index) => (
              <EventCard key={ev.id} ev={ev} index={index} onRsvp={openRsvp} />
            ))}
          </div>
        )}

        {/* Elegant Pagination Controls */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-4 border-t border-[#3E2723]/10 pt-10 mt-8">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="px-4 py-2 border border-[#3E2723]/15 text-[10px] md:text-sm font-bold uppercase tracking-wider hover:bg-[#3E2723] hover:text-[#F4F1EA] transition-all disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-[#3E2723] cursor-pointer"
            >
              Previous
            </button>

            <div className="flex items-center gap-2">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (page) => (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`w-8 h-8 rounded-full border text-xs md:text-sm font-semibold flex items-center justify-center transition-all cursor-pointer ${
                      currentPage === page
                        ? "bg-[#3E2723] text-[#F4F1EA] border-[#3E2723]"
                        : "border-[#3E2723]/15 hover:border-[#3E2723] opacity-75"
                    }`}
                  >
                    {page}
                  </button>
                ),
              )}
            </div>

            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="px-4 py-2 border border-[#3E2723]/15 text-[10px] md:text-sm font-bold uppercase tracking-wider hover:bg-[#3E2723] hover:text-[#F4F1EA] transition-all disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-[#3E2723] cursor-pointer"
            >
              Next
            </button>
          </div>
        )}
      </main>

      {/* RSVP Modal Overlay */}
      <RsvpModal
        isOpen={isRsvpOpen}
        activeEvent={activeEvent}
        onClose={() => setIsRsvpOpen(false)}
      />
    </div>
  );
}

// components/events-page/types.ts
export interface CafeEvent {
  id: number;

  category_en: string;
  category_de: string;

  heading_en: string;
  heading_de: string;

  subtitle_en: string;
  subtitle_de: string;

  description_en: string;
  description_de: string;

  image_url: string;

  date?: string;
  time?: string;
  location?: string;
  price?: string;

  frameType?: "walnut" | "gold" | "black" | "canvas";
}
